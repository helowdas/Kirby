package com.marbro.entities.player;

public enum EstadoKirby {
    QUIETO,
    CAMINANDO,
    SALTANDO,
    CAYENDO1,
    CAYENDO2,
    DESLIZANDOSE;
}
