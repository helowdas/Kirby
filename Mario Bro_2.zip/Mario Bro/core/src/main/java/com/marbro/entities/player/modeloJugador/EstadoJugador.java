package com.marbro.entities.player.modeloJugador;

public enum EstadoJugador {
    QUIETO,
    CAMINANDO,
    SALTANDO,
    CAYENDO1,
    CAYENDO2,
    DESLIZANDOSE
}
