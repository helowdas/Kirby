package com.marbro.entities.enemies.waddle_dee;

public enum EstadoWaddleDee {
    CAMINANDO,
    CAYENDO,
    HURT;
}
